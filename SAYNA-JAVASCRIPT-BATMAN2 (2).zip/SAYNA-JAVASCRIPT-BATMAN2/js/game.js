  // Define a variable to store the quiz questions
  let quizData = [];

  // Fetch quiz data from the JSON API
  fetch('https://batman-api.sayna.space/questions')
    .then(response => response.json())
    .then(data => {
      quizData = data;
      // Start the quiz when data is loaded
      startQuiz();
    })
    .catch(error => {
      console.error('Error fetching quiz data:', error);
    });

    // Function to start the quiz
    function startQuiz() {
        const quizContainer = document.getElementById('quiz-container');

        // Initialize variables for tracking the current question and score
        let currentQuestionIndex = 0;
        let score = 0;

        // Function to display the current question
        // Function to display the current question
    function displayQuestion() {
        const currentQuestion = quizData[currentQuestionIndex];
        if (currentQuestion) {
            // Create a container for the question and choices
            const questionDiv = document.createElement('div');
            questionDiv.className = 'question';
            questionDiv.innerHTML = `
            <p>${currentQuestion.question}</p>
            <form id="choices-form">
                <ul class="choices"></ul>
            </form>
            `;

            // Add choices to the container
            const choicesForm = questionDiv.querySelector('#choices-form');
            currentQuestion.response.forEach((choice, index) => {
            const choiceLabel = document.createElement('label');
            choiceLabel.innerHTML = `
                <input type="checkbox" name="choice" value="${choice.text}">
                ${choice.text}
            `;

            // Add change event to check if the choice is correct
            choiceLabel.addEventListener('change', () => {
                // Check if the selected choices are correct
                const selectedChoices = Array.from(
                choicesForm.querySelectorAll('input[type="checkbox"]:checked')
                ).map(checkbox => checkbox.value);

                // Check if all correct choices are selected
                const isCorrect = selectedChoices.every(selectedChoice =>
                currentQuestion.response.some(
                    choice => choice.text === selectedChoice && choice.isGood
                )
                );

                if (isCorrect) {
                score++;
                }

                // Display the next question or final result
                currentQuestionIndex++;
                if (currentQuestionIndex < quizData.length) {
                displayQuestion();
                } else {
                displayResult();
                }
            });

            choicesForm.appendChild(choiceLabel);
            });

            // Append the question container to the quiz container
            quizContainer.innerHTML = '';
            quizContainer.appendChild(questionDiv);
        } else {
            // If there are no more questions, display the final result
            displayResult();
        }
    }

    // Function to display the final result
    function displayResult() {
        let scores = score;
        if(scores <= 5)
        {
            quizContainer.innerHTML = `
            <p>${scores} / ${quizData.length} C'EST PAS TOUT A FAIT CA!</p>
            <p>Oula ! Heuresement que le Riddler est sous les verrous...Il faut que vous vous repassiez les films, cette fois en enlevant peut etre le masque qui vous bloqué lq vue! Aller, rien n'est perdu!</p>
          `;
        }
        else if(scores <= 10)
        {
            quizContainer.innerHTML = `
            <p>${scores} / ${quizData.length} PAS MAL!</p>
            <p>Encore un oeu d'entrainement avec le Chevalier Noir vous serait benefique, mais vous pouvez marcher la tete haute vos connaissances sont la. A vous de les consolider, foncez Gotham est votre terrain de chasse!
            `;
        }
        else
        {
            quizContainer.innerHTML = `
            <p>${scores} / ${quizData.length} BRAVO!</p>
            <p>Vous etes veritablement un super fan de l'univers de Batman! Comics, films, rien ne vous echappe. Bruce Wayne a de quoi etre fier, Gothan est en paix et Batman peut prendre sa retraite, vous veillez aux grain!</p>
            `;
        }
     
    }

    // Start the quiz by displaying the first question
    displayQuestion();
  }
